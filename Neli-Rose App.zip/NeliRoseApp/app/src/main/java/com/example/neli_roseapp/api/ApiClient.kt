package com.example.neli_roseapp.api

import android.content.Context
import com.google.android.gms.tasks.Tasks
import com.google.firebase.auth.FirebaseAuth
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import okhttp3.Interceptor
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit

object ApiConfig {
    const val DEFAULT_BASE_URL = "http://10.0.2.2:3000/"
    var currentBaseUrl: String = DEFAULT_BASE_URL

    fun getBaseUrl(context: Context): String {
        val saved = context.getSharedPreferences("neli_api_prefs", Context.MODE_PRIVATE)
            .getString("api_base_url", DEFAULT_BASE_URL)
        val url = saved ?: DEFAULT_BASE_URL
        currentBaseUrl = url
        return url
    }

    fun setBaseUrl(context: Context, url: String) {
        val parsed = url.trim().toHttpUrlOrNull()
            ?: throw IllegalArgumentException(
                "Enter a valid URL starting with http:// or https://"
            )

        require(parsed.username.isEmpty() && parsed.password.isEmpty()) {
            "Do not include a username or password in the URL."
        }

        require(parsed.query == null && parsed.fragment == null) {
            "Remove query parameters and fragments from the base URL."
        }

        val cleanUrl = parsed.toString().let {
            if (it.endsWith("/")) it else "$it/"
        }

        // Build the service before saving the setting.
        ApiClient.resetService(cleanUrl)

        context.getSharedPreferences("neli_api_prefs", Context.MODE_PRIVATE)
            .edit()
            .putString("api_base_url", cleanUrl)
            .apply()

        currentBaseUrl = cleanUrl
    }
}

object ApiClient {
    private var cachedService: NeliApiService? = null
    private var currentUrl: String = ApiConfig.DEFAULT_BASE_URL

    // Adds the signed-in user's Firebase ID token to every request.
    private val authInterceptor = Interceptor { chain ->
        val builder = chain.request().newBuilder()
        val user = runCatching { FirebaseAuth.getInstance().currentUser }.getOrNull()
        if (user != null) {
            val token = runCatching {
                Tasks.await(user.getIdToken(false), 10, TimeUnit.SECONDS).token
            }.getOrNull()
            if (token != null) builder.header("Authorization", "Bearer $token")
        }
        chain.proceed(builder.build())
    }

    private val okHttp: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(15, TimeUnit.SECONDS)
            .addInterceptor(authInterceptor)
            // BASIC logs only "POST /api/vitals 201" - never headers or bodies (no tokens or health data)
            .addInterceptor(HttpLoggingInterceptor().apply { level = HttpLoggingInterceptor.Level.BASIC })
            .build()
    }

    val service: NeliApiService
        get() {
            val url = ApiConfig.currentBaseUrl
            if (cachedService == null || currentUrl != url) {
                synchronized(this) {
                    currentUrl = url
                    cachedService = Retrofit.Builder()
                        .baseUrl(url)
                        .client(okHttp)
                        .addConverterFactory(GsonConverterFactory.create())
                        .build()
                        .create(NeliApiService::class.java)
                }
            }
            return cachedService!!
        }

    fun getServiceForContext(context: Context): NeliApiService {
        ApiConfig.getBaseUrl(context)
        return service
    }

    fun resetService(newUrl: String) {
        synchronized(this) {
            currentUrl = newUrl
            cachedService = Retrofit.Builder()
                .baseUrl(newUrl)
                .client(okHttp)
                .addConverterFactory(GsonConverterFactory.create())
                .build()
                .create(NeliApiService::class.java)
        }
    }
}
