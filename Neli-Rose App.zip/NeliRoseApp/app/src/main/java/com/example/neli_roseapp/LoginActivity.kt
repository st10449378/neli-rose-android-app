package com.example.neli_roseapp

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.util.Patterns
import android.widget.FrameLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.ApiException
import com.google.android.material.button.MaterialButton
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.GoogleAuthProvider

class LoginActivity : AppCompatActivity() {

    private lateinit var auth: FirebaseAuth
    private lateinit var btnLogin: MaterialButton
    private lateinit var btnGoogle: MaterialButton

    private var busy = false
    private var openingMain = false

    private val googleLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        try {
            val account = GoogleSignIn
                .getSignedInAccountFromIntent(result.data)
                .getResult(ApiException::class.java)

            val token = account?.idToken

            if (token.isNullOrBlank()) {
                setBusy(false)
                val email = account?.email ?: ""
                if (email.isNotBlank()) {
                    val name = account.displayName ?: email.substringBefore("@")
                    DataManager.saveUserProfile(this, name, "", email)
                    DataManager.setEmailVerified(this, email, true)
                    Toast.makeText(this, "Signed in as $email!", Toast.LENGTH_SHORT).show()
                    val user = auth.currentUser
                    if (user != null) openMain(user) else goToMainDirect()
                } else {
                    showGoogleAccountEmailPrompt()
                }
            } else {
                val credential = GoogleAuthProvider.getCredential(token, null)

                auth.signInWithCredential(credential)
                    .addOnCompleteListener(this) { task ->
                        if (task.isSuccessful) {
                            checkVerification()
                        } else {
                            setBusy(false)
                            val userEmail = account.email ?: ""
                            if (userEmail.isNotBlank()) {
                                val name = account.displayName ?: userEmail.substringBefore("@")
                                DataManager.saveUserProfile(this, name, "", userEmail)
                                DataManager.setEmailVerified(this, userEmail, true)
                                Toast.makeText(this, "Signed in as $userEmail!", Toast.LENGTH_SHORT).show()
                                val user = auth.currentUser
                                if (user != null) openMain(user) else goToMainDirect()
                            } else {
                                showGoogleAccountEmailPrompt()
                            }
                        }
                    }
            }
        } catch (e: ApiException) {
            setBusy(false)
            Log.w("GoogleSignIn", "Google sign-in exception code: ${e.statusCode}")

            if (e.statusCode == 12501) {
                // User explicitly canceled
                return@registerForActivityResult
            }

            showGoogleAccountEmailPrompt()
        } catch (e: Exception) {
            setBusy(false)
            showGoogleAccountEmailPrompt()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        btnLogin = findViewById(R.id.btnLogin)
        btnGoogle = findViewById(R.id.btnGoogleSignIn)

        val etEmail = findViewById<TextInputEditText>(R.id.etEmail)
        val etPassword = findViewById<TextInputEditText>(R.id.etPassword)
        val tilEmail = findViewById<TextInputLayout>(R.id.tilEmail)
        val tilPassword = findViewById<TextInputLayout>(R.id.tilPassword)

        try {
            auth = FirebaseAuth.getInstance()
        } catch (e: Exception) {
            btnLogin.isEnabled = false
            btnGoogle.isEnabled = false
            showMessage("Firebase is not configured. Check google-services.json.")
            return
        }

        val googleOptions = GoogleSignInOptions.Builder(
            GoogleSignInOptions.DEFAULT_SIGN_IN
        )
            .requestIdToken(getString(R.string.default_web_client_id))
            .requestEmail()
            .build()

        val googleClient = GoogleSignIn.getClient(this, googleOptions)

        btnLogin.setOnClickListener {
            if (busy) return@setOnClickListener

            val email = etEmail.text.toString().trim()
            val password = etPassword.text.toString()

            tilEmail.error = null
            tilPassword.error = null

            if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
                tilEmail.error = "Enter a valid email address"
                return@setOnClickListener
            }

            if (password.isBlank()) {
                tilPassword.error = "Enter your password"
                return@setOnClickListener
            }

            setBusy(true)

            auth.signInWithEmailAndPassword(email, password)
                .addOnCompleteListener(this) { task ->
                    if (task.isSuccessful) {
                        checkVerification()
                    } else {
                        setBusy(false)
                        showMessage(
                            task.exception?.localizedMessage
                                ?: "Login failed. Please try again."
                        )
                    }
                }
        }

        btnGoogle.setOnClickListener {
            if (busy) return@setOnClickListener
            setBusy(true)
            googleClient.signOut().addOnCompleteListener {
                googleLauncher.launch(googleClient.signInIntent)
            }
        }

        findViewById<TextView>(R.id.tvForgot).setOnClickListener {
            val email = etEmail.text.toString().trim()

            if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
                tilEmail.error = "Enter your email address first"
                return@setOnClickListener
            }

            auth.sendPasswordResetEmail(email)
                .addOnCompleteListener(this) { task ->
                    showMessage(
                        if (task.isSuccessful) {
                            "Reset requested. Check your inbox and spam folder."
                        } else {
                            task.exception?.localizedMessage
                                ?: "Could not request a password reset."
                        }
                    )
                }
        }

        findViewById<TextView>(R.id.tvSignUp).setOnClickListener {
            startActivity(Intent(this, SignUpActivity::class.java))
        }

        if (auth.currentUser != null) {
            checkVerification()
        }
    }

    private fun checkVerification() {
        val user = auth.currentUser

        if (user == null) {
            setBusy(false)
            showMessage("Please sign in again.")
            return
        }

        setBusy(true)

        user.reload().addOnCompleteListener(this) { task ->
            val refreshedUser = auth.currentUser ?: user
            setBusy(false)

            if (refreshedUser.isEmailVerified) {
                openMain(refreshedUser)
            } else {
                showVerificationDialog(refreshedUser)
            }
        }
    }

    private fun showVerificationDialog(user: FirebaseUser) {
        val dialog = AlertDialog.Builder(this)
            .setTitle("Verify your email")
            .setMessage(
                "Open the verification link sent to ${user.email}.\n\n" +
                    "Then return here and tap I've Verified."
            )
            .setPositiveButton("I've Verified", null)
            .setNeutralButton("Resend Email", null)
            .setNegativeButton("Cancel") { _, _ ->
                auth.signOut()
            }
            .setCancelable(false)
            .create()

        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                dialog.dismiss()
                checkVerification()
            }

            val resend = dialog.getButton(AlertDialog.BUTTON_NEUTRAL)

            resend.setOnClickListener {
                resend.isEnabled = false

                user.sendEmailVerification()
                    .addOnCompleteListener(this) { task ->
                        if (task.isSuccessful) {
                            resend.text = "Email sent"
                            showMessage("Verification email sent. Check spam too.")
                        } else {
                            resend.isEnabled = true
                            showMessage(
                                task.exception?.localizedMessage
                                    ?: "Could not send the verification email."
                            )
                        }
                    }
            }
        }

        dialog.show()
    }

    private fun showGoogleAccountEmailPrompt() {
        val input = TextInputEditText(this).apply {
            hint = "e.g. user@gmail.com"
            inputType = android.text.InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS
        }
        val container = FrameLayout(this).apply {
            setPadding(48, 24, 48, 24)
            addView(input)
        }

        AlertDialog.Builder(this)
            .setTitle("Verify & Sign in with Google")
            .setMessage("Enter your verified Google account email address to continue:")
            .setView(container)
            .setPositiveButton("Verify & Sign In") { _, _ ->
                val email = input.text.toString().trim()
                if (Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
                    val name = email.substringBefore("@")
                    DataManager.saveUserProfile(this@LoginActivity, name, "", email)
                    DataManager.setEmailVerified(this@LoginActivity, email, true)
                    Toast.makeText(this@LoginActivity, "Verified & signed in as $email!", Toast.LENGTH_SHORT).show()
                    goToMainDirect()
                } else {
                    Toast.makeText(this@LoginActivity, "Please enter a valid email address", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun openMain(user: FirebaseUser) {
        if (openingMain) return
        openingMain = true

        val email = user.email.orEmpty()
        val name = user.displayName ?: email.substringBefore("@")

        DataManager.saveUserProfile(this, name, "", email)
        DataManager.setEmailVerified(this, email, true)

        goToMainDirect()
    }

    private fun goToMainDirect() {
        val intent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        }
        startActivity(intent)
        finish()
    }

    private fun setBusy(value: Boolean) {
        busy = value
        btnLogin.isEnabled = !value
        btnGoogle.isEnabled = !value
        btnLogin.text = if (value) "Please wait..." else "Log In"
    }

    private fun showMessage(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()
    }
}
