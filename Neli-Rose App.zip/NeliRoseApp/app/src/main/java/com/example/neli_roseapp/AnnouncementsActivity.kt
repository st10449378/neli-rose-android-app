package com.example.neli_roseapp

import android.content.Context
import android.graphics.Typeface
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.Query
import java.text.SimpleDateFormat
import java.util.Locale

class AnnouncementsActivity : AppCompatActivity() {

    private val db = FirebaseFirestore.getInstance()
    private val auth = FirebaseAuth.getInstance()

    private var listener: ListenerRegistration? = null

    private lateinit var container: LinearLayout
    private lateinit var status: TextView
    private lateinit var progress: ProgressBar
    private lateinit var addButton: Button

    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(SettingsManager.wrap(newBase))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_announcements)

        container = findViewById(R.id.announcementsContainer)
        status = findViewById(R.id.tvAnnouncementsStatus)
        progress = findViewById(R.id.progressAnnouncements)
        addButton = findViewById(R.id.btnAddAnnouncement)

        findViewById<ImageView>(R.id.btnAnnouncementsBack)
            .setOnClickListener { finish() }

        addButton.visibility = View.VISIBLE
        addButton.setOnClickListener { showAddDialog() }
    }

    override fun onStart() {
        super.onStart()

        val user = auth.currentUser

        if (user == null) {
            progress.visibility = View.GONE
            status.visibility = View.VISIBLE
            status.text = "Please sign in to view announcements."
            addButton.visibility = View.GONE
            return
        }

        addButton.visibility = View.VISIBLE

        listenForAnnouncements()
    }

    private fun listenForAnnouncements() {
        listener?.remove()
        progress.visibility = View.VISIBLE

        listener = db.collection("announcements")
            .orderBy("createdAt", Query.Direction.DESCENDING)
            .limit(100)
            .addSnapshotListener { snapshot, error ->
                if (isFinishing || isDestroyed) {
                    return@addSnapshotListener
                }

                progress.visibility = View.GONE

                if (error != null) {
                    status.visibility = View.VISIBLE
                    status.text =
                        "Could not update announcements. Check your connection and access."
                    return@addSnapshotListener
                }

                container.removeAllViews()

                if (snapshot == null || snapshot.isEmpty) {
                    status.visibility = View.VISIBLE
                    status.text = "No announcements yet."
                    return@addSnapshotListener
                }

                status.visibility = View.GONE

                val formatter = SimpleDateFormat(
                    "dd MMM yyyy, HH:mm",
                    Locale.getDefault()
                )

                for (document in snapshot.documents) {
                    val date = document.getTimestamp("createdAt")?.toDate()

                    val card = LinearLayout(this).apply {
                        orientation = LinearLayout.VERTICAL
                        setPadding(dp(16), dp(16), dp(16), dp(16))
                        setBackgroundResource(R.drawable.bg_card)

                        layoutParams = LinearLayout.LayoutParams(
                            LinearLayout.LayoutParams.MATCH_PARENT,
                            LinearLayout.LayoutParams.WRAP_CONTENT
                        ).apply {
                            bottomMargin = dp(12)
                        }
                    }

                    card.addView(TextView(this).apply {
                        text = document.getString("title").orEmpty()
                        textSize = 19f
                        setTypeface(typeface, Typeface.BOLD)
                        setTextColor(getColor(R.color.neli_green))
                    })

                    card.addView(TextView(this).apply {
                        text = if (date != null) {
                            formatter.format(date)
                        } else {
                            "Waiting for server confirmation..."
                        }
                        textSize = 12f
                        setPadding(0, dp(6), 0, dp(8))
                    })

                    card.addView(TextView(this).apply {
                        text = document.getString("message").orEmpty()
                        textSize = 16f
                        setTextColor(getColor(R.color.neli_text_dark))
                    })

                    container.addView(card)
                }
            }
    }

    private fun showAddDialog() {
        val titleInput = EditText(this).apply {
            hint = "Announcement title"
            maxLines = 1
            filters = arrayOf(
                android.text.InputFilter.LengthFilter(100)
            )
        }

        val messageInput = EditText(this).apply {
            hint = "Type your announcement"
            minLines = 3
            inputType =
                android.text.InputType.TYPE_CLASS_TEXT or
                    android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE

            filters = arrayOf(
                android.text.InputFilter.LengthFilter(2000)
            )
        }

        val form = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), dp(8))
            addView(titleInput)
            addView(messageInput)
        }

        val dialog = AlertDialog.Builder(this)
            .setTitle("Add announcement")
            .setView(form)
            .setPositiveButton("Publish", null)
            .setNegativeButton("Cancel", null)
            .create()

        // Reuse this ID if a failed write is retried.
        val document = db.collection("announcements").document()

        dialog.setOnShowListener {
            val publish = dialog.getButton(AlertDialog.BUTTON_POSITIVE)
            val cancel = dialog.getButton(AlertDialog.BUTTON_NEGATIVE)

            publish.setOnClickListener {
                val title = titleInput.text.toString().trim()
                val message = messageInput.text.toString().trim()
                val user = auth.currentUser

                if (title.isBlank()) {
                    titleInput.error = "Enter a title"
                    return@setOnClickListener
                }

                if (message.isBlank()) {
                    messageInput.error = "Enter a message"
                    return@setOnClickListener
                }

                if (user == null) {
                    Toast.makeText(
                        this,
                        "Please sign in again.",
                        Toast.LENGTH_LONG
                    ).show()
                    return@setOnClickListener
                }

                publish.isEnabled = false
                cancel.isEnabled = false
                titleInput.isEnabled = false
                messageInput.isEnabled = false
                publish.text = "Publishing..."
                dialog.setCancelable(false)

                val announcement = hashMapOf(
                    "title" to title,
                    "message" to message,
                    "authorId" to user.uid,
                    "createdAt" to FieldValue.serverTimestamp()
                )

                document.set(announcement)
                    .addOnSuccessListener(this) {
                        dialog.dismiss()

                        Toast.makeText(
                            this,
                            "Announcement published.",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                    .addOnFailureListener(this) {
                        publish.isEnabled = true
                        cancel.isEnabled = true
                        titleInput.isEnabled = true
                        messageInput.isEnabled = true
                        publish.text = "Publish"
                        dialog.setCancelable(true)

                        Toast.makeText(
                            this,
                            "Could not publish. Check your connection and try again.",
                            Toast.LENGTH_LONG
                        ).show()
                    }
            }
        }

        dialog.show()
    }

    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density).toInt()

    override fun onStop() {
        listener?.remove()
        listener = null
        super.onStop()
    }
}
